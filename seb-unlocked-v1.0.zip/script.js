// Game Data
const gameData = [
    {
        "id": 1,
        "title": "Grand Theft Auto V | GTA V",
        "description": "Explore the massive open world of Los Santos and Blaine County with three playable characters: Michael, Franklin, and Trevor. Engage in heists and chaos in this critically acclaimed action game.",
        "parts": 22,
        "requirements": {
            "cpu": "Intel Core 2 Quad Q6600 or AMD Phenom 9850",
            "ram": "4 GB RAM",
            "gpu": "NVIDIA 9800 GT 1 GB or AMD HD 4870 1 GB",
            "storage": "72 GB available space"
        },
        "images": [
            "https://assetsio.gnwcdn.com/eurogamer-zjp1vx.jpg?width=1200&height=1200&fit=bounds&quality=70&format=jpg&auto=webp",
            "https://appnation4d.home.blog/wp-content/uploads/2019/04/gta-v-pc-game-free-download-full.jpg",
            "https://i.ytimg.com/vi/d74REG039Dk/maxresdefault.jpg"
        ]
    },
    {
        "id": 2,
        "title": "Grand Theft Auto: San Andreas | GTA San Andreas",
        "description": "Join Carl \" CJ\" Johnson as he returns to Grove Street to restore his family and gang while navigating the sprawling state of San Andreas.",
        "parts": 2,
        "requirements": {
            "cpu": "1 GHz Intel Pentium III or AMD Athlon",
            "ram": "256 MB RAM",
            "gpu": "64 MB Direct3D Video Card",
            "storage": "4.7 GB available space"
        },
        "images": [
            "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p3/132/2024/11/10/Cara-Mudah-dan-Lengkap-Download-GTA-San-Andreas-Mod-APK-Mod-Hello-Gratis-Bahasa-Indonesia-di-HP-Android-dengan-Aman-2165756163.jpg",
            "https://user-images.githubusercontent.com/4572452/62012796-0db44800-b18b-11e9-9606-3a97ad6bd455.jpg",
            "https://i.ytimg.com/vi/xJ-1ve1vynA/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBzpsqr02sgpTx6RrcTNYqGj27LNw"
        ]
    },
    {
        "id": 3,
        "title": "Grand Theft Auto IV | GTA IV",
        "description": "Experience Niko Bellic's story as he arrives in Liberty City to pursue the American Dream while dealing with his criminal past.",
        "parts": 7,
        "requirements": {
            "cpu": "Intel Core 2 Duo 1.8 GHz or AMD Athlon X2 64 2.4 GHz",
            "ram": "1.5 GB RAM",
            "gpu": "256 MB NVIDIA 7900+ or 256 MB ATI X1900+",
            "storage": "16 GB available space"
        },
        "images": [
            "https://i.ytimg.com/vi/KaUadE80R6E/maxresdefault.jpg",
            "https://i.ytimg.com/vi/3STIbmjWXRI/maxresdefault.jpg",
            "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi5NXQM-9tObVPMXw8oWnk-rhW8BVunl7LxhWBZJ_hu0iHx0zUpt8O4DehKWEQ5xs4bqEdVhzrnnIWeOdlxDg2qf63wXON2ve0tUP4skXxgrZCBV52WJyWXsfp62p3qkx83bpc7zQMyyTQ/s1600/GTA4_city.jpg"
        ]
    },
    {
        "id": 4,
        "title": "Grand Theft Auto: Vice City | GTA Vice City",
        "description": "Explore the vibrant streets of Vice City in the 1980s. Experience the rise of Tommy Vercetti as he builds his criminal empire in this neon-lit open-world game.",
        "parts": 2,
        "requirements": {
            "cpu": "800 MHz Intel Pentium III or AMD Athlon",
            "ram": "128 MB RAM",
            "gpu": "32 MB Direct3D Video Card",
            "storage": "915 MB available space"
        },
        "images": [
            "https://jeux.ca/wp-content/uploads/2024/05/GTA-Vice-City-featured.jpg",
            "https://i.ytimg.com/vi/I_z1RVX_YA4/maxresdefault.jpg",
            "https://i.ytimg.com/vi/LB1gs3ORDGU/maxresdefault.jpg"
        ]
    },
    {
        "id": 5,
        "title": "Grand Theft Auto III | GTA III",
        "description": "Step into Liberty City, a gritty metropolis filled with crime and chaos. Follow Claude's journey in this open-world action-adventure game that revolutionized 3D gameplay.",
        "parts": 1,
        "requirements": {
            "cpu": "Pentium III 450 MHz or AMD Athlon 600 MHz",
            "ram": "96 MB RAM",
            "gpu": "16 MB Direct3D Video Card",
            "storage": "500 MB available space"
        },
        "images": [
            "https://cdn1.epicgames.com/offer/ec64a50e79884e28be9ac3d3cd4f5c12/EGS_GrandTheftAutoIIITheDefinitiveEdition_RockstarGames_S1_2560x1440-5e44468c38f50805cac5ab47748d7b79",
            "https://i.ytimg.com/vi/tM8KKIoZ5dA/maxresdefault.jpg",
            "https://i.ytimg.com/vi/ztEe4fDcOxw/maxresdefault.jpg"
        ]
    },
    {
        "id": 6,
        "title": "Red Dead Redemption 2 | RDR 2",
        "description": "Immerse yourself in the story of Arthur Morgan and the Van der Linde gang as they struggle to survive in America's unforgiving heartland.",
        "parts": 28,
        "requirements": {
            "cpu": "Intel Core i5-2500K or AMD FX-6300",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 770 2GB or AMD R9 280 3GB",
            "storage": "150 GB available space"
        },
        "images": [
            "https://cdn1.epicgames.com/b30b6d1b4dfd4dcc93b5490be5e094e5/offer/RDR2476298253_Epic_Games_Wishlist_RDR2_2560x1440_V01-2560x1440-2a9ebe1f7ee202102555be202d5632ec.jpg",
            "https://s2.dmcdn.net/v/SmssV1Xs-qs0x_3_5/x1080",
            "https://i.ytimg.com/vi/Ak9lA98lUx4/maxresdefault.jpg"
        ]
    },
    {
        "id": 7,
        "title": "Forza Horizon 4",
        "description": "Experience dynamic seasons in the stunningly beautiful open world of Britain. Race, stunt, and explore solo or with friends.",
        "parts": 23,
        "requirements": {
            "cpu": "Intel i3-4170 or AMD FX-6120",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 650 Ti or AMD R7 250X",
            "storage": "80 GB available space"
        },
        "images": [
            "https://ulvespill.net/wp-content/uploads/2018/09/Forza-Horizon-4-Key-Art-Horizontal.jpg",
            "https://i.ytimg.com/vi/ejVlWiYER1M/maxresdefault.jpg",
            "https://images.gamersyde.com/image_stream-42806-2069_0002.jpg"
        ]
    },
    {
        "id": 8,
        "title": "Need for Speed: Most Wanted | NFS Most Wanted",
        "description": "Outrun the police and your rivals in this high-octane street racing game that became a classic in the NFS series.",
        "parts": 1,
        "requirements": {
            "cpu": "1.4 GHz Pentium 4 or equivalent",
            "ram": "256 MB RAM",
            "gpu": "32 MB Direct3D Video Card",
            "storage": "3 GB available space"
        },
        "images": [
            "https://mods.store.gx.me/mod/a8903921-a7f6-4b7a-ae63-771bf779e855/cover/242dd251-a963-4ea8-adb9-ae9b4ecb224c/webp-1280x720?d87fa3494354aef6d1dd9323d5207128",
            "https://i.ytimg.com/vi/KbO7Fs4vLvs/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBHSrWSj7lGNc2_weetAlrlaVjNPw",
            "https://s2.dmcdn.net/v/Sxa1H1WZmifvDGw0I/x1080"
        ]
    },
    {
        "id": 14,
        "title": "FIFA 18",
        "description": "Experience the excitement of football with stunning graphics and gameplay enhancements in FIFA 18.",
        "parts": 18,
        "requirements": {
            "cpu": "Intel Core i3-2100 or AMD Phenom II X4 965",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 460 or AMD Radeon R7 260",
            "storage": "50 GB available space"
        },
        "images": [
            "https://www.nintendo.com/eu/media/images/10_share_images/games_15/nintendo_switch_4/H2x1_NSwitch_EASportsFifa18_image1280w.jpg",
            "https://www.jiomart.com/images/product/original/rvggle1l87/electronic-arts-sports-fifa-18-ps4-product-images-orvggle1l87-p604093135-1-202308251436.jpg?im=Resize=(1000,1000)",
            "https://www.godisageek.com/wp-content/uploads/fifa-18-career-mode-liverpool.jpg"
        ]
    },
    {
        "id": 15,
        "title": "Minecraft",
        "description": "Build, explore, and survive in this blocky, pixelated world filled with endless possibilities.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Core i3-3210 or AMD A8-7600",
            "ram": "4 GB RAM",
            "gpu": "Intel HD Graphics 4000 or AMD Radeon R5",
            "storage": "1 GB available space"
        },
        "images": [
            "https://assets.nuuvem.com/image/upload/v1/products/62f3c54f65d8fa7046eea12e/sharing_images/vvmelr55khbxp3myxj46.jpg",
            "https://cdn.britannica.com/62/200262-050-AFE1BDFF/Players-Minecraft-worlds-way-blocks-roaming-characters.jpg",
            "https://www.merlinentertainments.biz/media/6803/images-courtesy-of-merlin-and-tm-mojang-ab-2.jpg?anchor=center&mode=crop&width=980&height=570&rnd=133763995550000000&format=webp"
        ]
    },
    {
        "id": 12,
        "title": "Bully: Scholarship Edition",
        "description": "Play as Jimmy Hopkins as you navigate the social hierarchy of Bullworth Academy in this action-adventure game filled with pranks and challenges.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Pentium 4 (3+ GHZ) / AMD Athlon 3000+",
            "ram": "1 GB RAM",
            "gpu": "NVIDIA 6800 or ATI Radeon X1300",
            "storage": "4.7 GB available space"
        },
        "images": [
            "https://crotorrents.com/wp-content/uploads/2017/04/download-6.jpg",
            "https://thepcgames.net/wp-content/uploads/2018/04/Bully-Scholarship-Edition-PC-Game-Free-Download.jpg",
            "https://i.ytimg.com/vi/BVSghGUqALI/hq720.jpg?sqp=-oaymwE7CK4FEIIDSFryq4qpAy0IARUAAAAAGAElAADIQj0AgKJD8AEB-AH-CYAC0AWKAgwIABABGGUgWShNMA8=&rs=AOn4CLAh4cpWTcXBL_6sOb04Frn-5bVBRg"
        ]
    },
    {
        "id": 13,
        "title": "Granny",
        "description": "Survive and escape a creepy house while avoiding the wrath of Granny in this thrilling horror game.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Core 2 Duo or equivalent",
            "ram": "2 GB RAM",
            "gpu": "Intel HD Graphics 4000",
            "storage": "500 MB available space"
        },
        "images": [
            "https://i.ytimg.com/vi/pURCRidtEZY/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAeprzon9DQK_SNhrzFIn1WcrFgYw",
            "https://i.ytimg.com/vi/S6l4nQrR2aE/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLB0JwshFAz-5Htq9HTD8DjMvCTBKQ",
            "https://a.silvergames.com/screenshots/granny-horror/horror-game.jpg"
        ]
    },
    {
        "id": 9,
        "title": "Euro Truck Simulator 2 | ETS 2",
        "description": "Experience the life of a truck driver as you deliver cargo across Europe in this realistic truck simulator.",
        "parts": 6,
        "requirements": {
            "cpu": "Dual core CPU 2.4 GHz",
            "ram": "4 GB RAM",
            "gpu": "GeForce GTS 450-class (Intel HD 4000)",
            "storage": "3 GB available space"
        },
        "images": [
            "https://infiniteczechgames.com/wp-content/uploads/2023/11/Euro-Truck-Simulator-2-cover.jpg",
            "https://i.ytimg.com/vi/gtxWdNcRsqY/hq720.jpg?sqp=-oaymwE7CK4FEIIDSFryq4qpAy0IARUAAAAAGAElAADIQj0AgKJD8AEB-AH-CYAC0AWKAgwIABABGEsgXShlMA8=&rs=AOn4CLBvQktvcNxaJeIcAnBfh7ybpknobQ",
            "https://i.ytimg.com/vi/zUT0JsR5KYM/maxresdefault.jpg"
        ]
    },
    {
        "id": 10,
        "title": "BeamNG.drive",
        "description": "Experience realistic soft-body physics and open-world exploration with a variety of vehicles in this driving simulation.",
        "parts": 1,
        "requirements": {
            "cpu": "AMD FX-6300 or Intel i5-4430",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 550 Ti or AMD HD 7750",
            "storage": "20 GB available space"
        },
        "images": [
            "https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/284160/capsule_616x353.jpg?t=1733838013",
            "https://i.ytimg.com/vi/HHLcj6T8YFk/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAvaOBBx0XHwObKgW_x8KKFEYp93g",
            "https://i.ytimg.com/vi/lUKYMavgDCY/maxresdefault.jpg"
        ]
    }
];

// Current state
let currentSlide = 0;
let currentGame = null;

// Loading Screen
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        document.getElementById('loadingScreen').style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
        initializeGames();
    }, 2000);
});

// Initialize game cards
function initializeGames() {
    const gameGrid = document.getElementById('gameGrid');
    gameGrid.innerHTML = '';

    gameData.forEach(game => {
        const card = createGameCard(game);
        gameGrid.appendChild(card);
    });
}

// Create game card element
function createGameCard(game) {
    const card = document.createElement('div');
    card.className = 'game-card';
    card.innerHTML = `
        <img src="${game.images[0]}" alt="${game.title}" class="game-image">
        <div class="game-info">
            <h3 class="game-title">${game.title}</h3>
            <p class="game-parts">Parts: ${game.parts}</p>
            <button class="download-btn" onclick="showGameDetails(${game.id})">
                Download
            </button>
        </div>
    `;
    return card;
}

// Search functionality
const searchBar = document.getElementById('searchBar');
searchBar.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.game-card');
    
    cards.forEach(card => {
        const title = card.querySelector('.game-title').textContent.toLowerCase();
        card.style.display = title.includes(searchTerm) ? 'block' : 'none';
    });
});

// Show game details popup
function showGameDetails(gameId) {
    currentGame = gameData.find(game => game.id === gameId);
    if (!currentGame) return;

    const popup = document.getElementById('gamePopup');
    const slideshow = document.getElementById('slideshow');
    const dots = document.getElementById('slideDots');
    
    // Set game info
    document.getElementById('popupGameTitle').textContent = currentGame.title;
    document.getElementById('popupGameDescription').textContent = currentGame.description;
    
    // Set requirements
    const reqList = document.getElementById('popupRequirements');
    reqList.innerHTML = `
        <li>CPU: ${currentGame.requirements.cpu}</li>
        <li>RAM: ${currentGame.requirements.ram}</li>
        <li>GPU: ${currentGame.requirements.gpu}</li>
    `;
    document.getElementById('popupStorage').textContent = currentGame.requirements.storage;

    // Set up slideshow
    slideshow.innerHTML = '';
    dots.innerHTML = '';
    currentGame.images.forEach((img, index) => {
        // Create slide
        const slide = document.createElement('div');
        slide.className = `slide ${index === 0 ? 'active' : ''}`;
        slide.innerHTML = `<img src="${img}" alt="${currentGame.title} Screenshot ${index + 1}">`;
        slideshow.appendChild(slide);

        // Create dot
        const dot = document.createElement('span');
        dot.className = `dot ${index === 0 ? 'active' : ''}`;
        dot.onclick = () => goToSlide(index);
        dots.appendChild(dot);
    });

    // Set up download buttons
    const downloadButtons = document.getElementById('downloadButtons');
    downloadButtons.innerHTML = '';
    for (let i = 1; i <= currentGame.parts; i++) {
        const button = document.createElement('button');
        button.className = 'download-btn';
        button.textContent = `Download Part ${i}`;
        button.onclick = () => initiateDownload(currentGame.title, i);
        downloadButtons.appendChild(button);
    }

    // Show popup
    popup.style.display = 'flex';
    currentSlide = 0;
}

// Slideshow navigation
function changeSlide(direction) {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    
    slides[currentSlide].classList.remove('active');
    dots[currentSlide].classList.remove('active');
    
    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    
    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

function goToSlide(slideIndex) {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    
    slides[currentSlide].classList.remove('active');
    dots[currentSlide].classList.remove('active');
    
    currentSlide = slideIndex;
    
    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

// Close popup
function closePopup() {
    const popup = document.getElementById('gamePopup');
    popup.style.display = 'none';
    currentGame = null;
    currentSlide = 0;
}

// Download functionality
function initiateDownload(gameTitle, partNumber) {
    // This is where you would implement the actual download logic
    alert(`Downloading ${gameTitle} - Part ${partNumber}`);
}

// Background animation
function createParticles() {
    const background = document.querySelector('.background-animation');
    if (!background) {
        console.error('Background animation element not found!');
        return;
    }
    for (let i = 0; i < 100; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.animationDuration = `${4 + Math.random() * 10}s`;
        particle.style.animationDelay = `${Math.random() * 5}s`;
        background.appendChild(particle);
    }
    console.log('Particles created successfully');
}

createParticles();


// Keyboard navigation for slideshow
document.addEventListener('keydown', (e) => {
    if (currentGame) {
        if (e.key === 'ArrowLeft') changeSlide(-1);
        if (e.key === 'ArrowRight') changeSlide(1);
        if (e.key === 'Escape') closePopup();
    }
});

// Close popup when clicking outside
document.getElementById('gamePopup').addEventListener('click', (e) => {
    if (e.target.id === 'gamePopup') {
        closePopup();
    }
});