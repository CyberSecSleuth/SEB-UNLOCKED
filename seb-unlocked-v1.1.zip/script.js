// Game Data
const gameData = [
    {
        "id": 1,
        "title": "Grand Theft Auto V | GTA V",
        "description": "Explore the massive open world of Los Santos and Blaine County with three playable characters: Michael, Franklin, and Trevor. Engage in heists and chaos in this critically acclaimed action game.",
        "parts": 22,
        "requirements": {
            "cpu": "Intel Core 2 Quad Q6600 or AMD Phenom 9850",
            "ram": "4 GB RAM",
            "gpu": "NVIDIA 9800 GT 1 GB or AMD HD 4870 1 GB",
            "storage": "72 GB available space"
        },
        "images": [
            "https://assetsio.gnwcdn.com/eurogamer-zjp1vx.jpg?width=1200&height=1200&fit=bounds&quality=70&format=jpg&auto=webp",
            "https://appnation4d.home.blog/wp-content/uploads/2019/04/gta-v-pc-game-free-download-full.jpg",
            "https://i.ytimg.com/vi/d74REG039Dk/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/525709/GTA+V+-+ATOM+GUY+EDITION.part01.rar?hash=AgADdh",
            "https://linksshortner.xyz/525706/GTA+V+-+ATOM+GUY+EDITION.part02.rar?hash=AgADjx",
            "https://linksshortner.xyz/525700/GTA+V+-+ATOM+GUY+EDITION.part03.rar?hash=AgADkR",
            "https://linksshortner.xyz/525696/GTA+V+-+ATOM+GUY+EDITION.part04.rar?hash=AgADkx",
            "https://linksshortner.xyz/525698/GTA+V+-+ATOM+GUY+EDITION.part05.rar?hash=AgADlR",
            "https://linksshortner.xyz/525702/GTA+V+-+ATOM+GUY+EDITION.part06.rar?hash=AgADlx",
            "https://linksshortner.xyz/525704/GTA+V+-+ATOM+GUY+EDITION.part07.rar?hash=AgADmB",
            "https://linksshortner.xyz/525707/GTA+V+-+ATOM+GUY+EDITION.part08.rar?hash=AgADmh",
            "https://linksshortner.xyz/525707/GTA+V+-+ATOM+GUY+EDITION.part08.rar?hash=AgADmh",
            "https://linksshortner.xyz/525708/GTA+V+-+ATOM+GUY+EDITION.part09.rar?hash=AgADmx",
            "https://linksshortner.xyz/525712/GTA+V+-+ATOM+GUY+EDITION.part10.rar?hash=AgADnB",
            "https://linksshortner.xyz/525716/GTA+V+-+ATOM+GUY+EDITION.part11.rar?hash=AgADnh",
            "https://linksshortner.xyz/525717/GTA+V+-+ATOM+GUY+EDITION.part12.rar?hash=AgADnx",
            "https://linksshortner.xyz/525718/GTA+V+-+ATOM+GUY+EDITION.part13.rar?hash=AgADoB",
            "https://linksshortner.xyz/525719/GTA+V+-+ATOM+GUY+EDITION.part14.rar?hash=AgADoR",
            "https://linksshortner.xyz/525724/GTA+V+-+ATOM+GUY+EDITION.part15.rar?hash=AgADox",
            "https://linksshortner.xyz/525725/GTA+V+-+ATOM+GUY+EDITION.part16.rar?hash=AgADpB",
            "https://linksshortner.xyz/525726/GTA+V+-+ATOM+GUY+EDITION.part17.rar?hash=AgADqR",
            "https://linksshortner.xyz/525726/GTA+V+-+ATOM+GUY+EDITION.part17.rar?hash=AgADqR",
            "https://linksshortner.xyz/525728/GTA+V+-+ATOM+GUY+EDITION.part18.rar?hash=AgADqh",
            "https://linksshortner.xyz/525729/GTA+V+-+ATOM+GUY+EDITION.part19.rar?hash=AgADrx",
            "https://linksshortner.xyz/525734/GTA+V+-+ATOM+GUY+EDITION.part20.rar?hash=AgADtx",
            "https://linksshortner.xyz/525735/GTA+V+-+ATOM+GUY+EDITION.part21.rar?hash=AgADuh",
            "https://linksshortner.xyz/525737/GTA+V+-+ATOM+GUY+EDITION.part22.rar?hash=AgADvx"
        ]
    },
    {
        "id": 2,
        "title": "Grand Theft Auto: San Andreas | GTA San Andreas",
        "description": "Join Carl \" CJ\" Johnson as he returns to Grove Street to restore his family and gang while navigating the sprawling state of San Andreas.",
        "parts": 2,
        "requirements": {
            "cpu": "1 GHz Intel Pentium III or AMD Athlon",
            "ram": "256 MB RAM",
            "gpu": "64 MB Direct3D Video Card",
            "storage": "4.7 GB available space"
        },
        "images": [
            "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p3/132/2024/11/10/Cara-Mudah-dan-Lengkap-Download-GTA-San-Andreas-Mod-APK-Mod-Hello-Gratis-Bahasa-Indonesia-di-HP-Android-dengan-Aman-2165756163.jpg",
            "https://user-images.githubusercontent.com/4572452/62012796-0db44800-b18b-11e9-9606-3a97ad6bd455.jpg",
            "https://i.ytimg.com/vi/xJ-1ve1vynA/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBzpsqr02sgpTx6RrcTNYqGj27LNw"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/525692/LQ+GTA+SA+ATOM+GUY.rar?hash=AgAD_x",
            "https://linksshortner.xyz/525749/GTA+SA+ANDROID+ATOM+GUY+EDITION.zip?hash=AgAD8Q"
        ]
    },
    {
        "id": 3,
        "title": "Grand Theft Auto IV | GTA IV",
        "description": "Experience Niko Bellic's story as he arrives in Liberty City to pursue the American Dream while dealing with his criminal past.",
        "parts": 7,
        "requirements": {
            "cpu": "Intel Core 2 Duo 1.8 GHz or AMD Athlon X2 64 2.4 GHz",
            "ram": "1.5 GB RAM",
            "gpu": "256 MB NVIDIA 7900+ or 256 MB ATI X1900+",
            "storage": "16 GB available space"
        },
        "images": [
            "https://i.ytimg.com/vi/KaUadE80R6E/maxresdefault.jpg",
            "https://i.ytimg.com/vi/3STIbmjWXRI/maxresdefault.jpg",
            "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi5NXQM-9tObVPMXw8oWnk-rhW8BVunl7LxhWBZJ_hu0iHx0zUpt8O4DehKWEQ5xs4bqEdVhzrnnIWeOdlxDg2qf63wXON2ve0tUP4skXxgrZCBV52WJyWXsfp62p3qkx83bpc7zQMyyTQ/s1600/GTA4_city.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/527902/GTA+IV+-+ATOM+GUY+EDITION.part01.rar?hash=AgADZh",
            "https://linksshortner.xyz/527913/GTA+IV+-+ATOM+GUY+EDITION.part02.rar?hash=AgADbB",
            "https://linksshortner.xyz/527912/GTA+IV+-+ATOM+GUY+EDITION.part03.rar?hash=AgADbh",
            "https://linksshortner.xyz/527906/GTA+IV+-+ATOM+GUY+EDITION.part04.rar?hash=AgADcx",
            "https://linksshortner.xyz/527904/GTA+IV+-+ATOM+GUY+EDITION.part05.rar?hash=AgADdh",
            "https://linksshortner.xyz/527908/GTA+IV+-+ATOM+GUY+EDITION.part06.rar?hash=AgADeB",
            "https://linksshortner.xyz/527910/GTA+IV+-+ATOM+GUY+EDITION.part07.rar?hash=AgADih"
        ]
    },
    {
        "id": 4,
        "title": "Grand Theft Auto: Vice City | GTA Vice City",
        "description": "Explore the vibrant streets of Vice City in the 1980s. Experience the rise of Tommy Vercetti as he builds his criminal empire in this neon-lit open-world game.",
        "parts": 2,
        "requirements": {
            "cpu": "800 MHz Intel Pentium III or AMD Athlon",
            "ram": "128 MB RAM",
            "gpu": "32 MB Direct3D Video Card",
            "storage": "915 MB available space"
        },
        "images": [
            "https://jeux.ca/wp-content/uploads/2024/05/GTA-Vice-City-featured.jpg",
            "https://i.ytimg.com/vi/I_z1RVX_YA4/maxresdefault.jpg",
            "https://i.ytimg.com/vi/LB1gs3ORDGU/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/525690/LQ+GTA+VC+ATOM+GUY.rar?hash=AgADCR",
            "https://linksshortner.xyz/525747/GTA+VC+ANDROID+ATOM+GUY+EDITION.zip?hash=AgADtR"
        ]
    },
    {
        "id": 5,
        "title": "Grand Theft Auto III | GTA III",
        "description": "Step into Liberty City, a gritty metropolis filled with crime and chaos. Follow Claude's journey in this open-world action-adventure game that revolutionized 3D gameplay.",
        "parts": 1,
        "requirements": {
            "cpu": "Pentium III 450 MHz or AMD Athlon 600 MHz",
            "ram": "96 MB RAM",
            "gpu": "16 MB Direct3D Video Card",
            "storage": "500 MB available space"
        },
        "images": [
            "https://cdn1.epicgames.com/offer/ec64a50e79884e28be9ac3d3cd4f5c12/EGS_GrandTheftAutoIIITheDefinitiveEdition_RockstarGames_S1_2560x1440-5e44468c38f50805cac5ab47748d7b79",
            "https://i.ytimg.com/vi/tM8KKIoZ5dA/maxresdefault.jpg",
            "https://i.ytimg.com/vi/ztEe4fDcOxw/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/525688/LQ+GTA+3+ATOM+GUY.rar?hash=AgADDR"
        ]
    },
    {
        "id": 6,
        "title": "Red Dead Redemption 2 | RDR 2",
        "description": "Immerse yourself in the story of Arthur Morgan and the Van der Linde gang as they struggle to survive in America's unforgiving heartland.",
        "parts": 28,
        "requirements": {
            "cpu": "Intel Core i5-2500K or AMD FX-6300",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 770 2GB or AMD R9 280 3GB",
            "storage": "150 GB available space"
        },
        "images": [
            "https://cdn1.epicgames.com/b30b6d1b4dfd4dcc93b5490be5e094e5/offer/RDR2476298253_Epic_Games_Wishlist_RDR2_2560x1440_V01-2560x1440-2a9ebe1f7ee202102555be202d5632ec.jpg",
            "https://s2.dmcdn.net/v/SmssV1Xs-qs0x_3_5/x1080",
            "https://i.ytimg.com/vi/Ak9lA98lUx4/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664457/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part01.rar?hash=AgAD1Q",
            "https://linksshortner.xyz/664467/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part02.rar?hash=AgAD1g",
            "https://linksshortner.xyz/664480/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part03.rar?hash=AgADkx",
            "https://linksshortner.xyz/664469/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part04.rar?hash=AgADlx",
            "https://linksshortner.xyz/664459/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part05.rar?hash=AgAD2Q",
            "https://linksshortner.xyz/664461/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part06.rar?hash=AgADnB",
            "https://linksshortner.xyz/664463/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part07.rar?hash=AgADpB",
            "https://linksshortner.xyz/664465/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part08.rar?hash=AgADqB",
            "https://linksshortner.xyz/664468/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part09.rar?hash=AgADrh",
            "https://linksshortner.xyz/664472/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part10.rar?hash=AgADYQ",
            "https://linksshortner.xyz/664474/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part11.rar?hash=AgADYg",
            "https://linksshortner.xyz/664476/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part12.rar?hash=AgADZA",
            "https://linksshortner.xyz/664478/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part13.rar?hash=AgADaQ",
            "https://linksshortner.xyz/664479/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part14.rar?hash=AgADbw",
            "https://linksshortner.xyz/664484/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part15.rar?hash=AgADcA",
            "https://linksshortner.xyz/664490/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part16.rar?hash=AgADcg",
            "https://linksshortner.xyz/664486/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part17.rar?hash=AgADcw",
            "https://linksshortner.xyz/664488/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part18.rar?hash=AgADdA",
            "https://linksshortner.xyz/664489/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part19.rar?hash=AgADdQ",
            "https://linksshortner.xyz/664493/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part20.rar?hash=AgADdg",
            "https://linksshortner.xyz/664496/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part21.rar?hash=AgADeA",
            "https://linksshortner.xyz/664495/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part22.rar?hash=AgADeQ",
            "https://linksshortner.xyz/664501/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part23.rar?hash=AgADew",
            "https://linksshortner.xyz/664505/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part24.rar?hash=AgADfg",
            "https://linksshortner.xyz/664503/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part25.rar?hash=AgADfw",
            "https://linksshortner.xyz/664506/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part26.rar?hash=AgADgA",
            "https://linksshortner.xyz/664504/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part27.rar?hash=AgADgQ",
            "https://linksshortner.xyz/664509/RED+DEAD+REDEMPTION+2+-+ATOM+GUY.part28.rar?hash=AgADgg"
        ]
    },
    {
        "id": 7,
        "title": "Forza Horizon 4",
        "description": "Experience dynamic seasons in the stunningly beautiful open world of Britain. Race, stunt, and explore solo or with friends.",
        "parts": 23,
        "requirements": {
            "cpu": "Intel i3-4170 or AMD FX-6120",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 650 Ti or AMD R7 250X",
            "storage": "80 GB available space"
        },
        "images": [
            "https://ulvespill.net/wp-content/uploads/2018/09/Forza-Horizon-4-Key-Art-Horizontal.jpg",
            "https://i.ytimg.com/vi/ejVlWiYER1M/maxresdefault.jpg",
            "https://images.gamersyde.com/image_stream-42806-2069_0002.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664598/Forza+Horizon+4+-+Atom+Guy.part01.rar?hash=AgADRx",
            "https://linksshortner.xyz/664588/Forza+Horizon+4+-+Atom+Guy.part02.rar?hash=AgADTh",
            "https://linksshortner.xyz/664607/Forza+Horizon+4+-+Atom+Guy.part03.rar?hash=AgADWh",
            "https://linksshortner.xyz/664600/Forza+Horizon+4+-+Atom+Guy.part04.rar?hash=AgADXh",
            "https://linksshortner.xyz/664590/Forza+Horizon+4+-+Atom+Guy.part05.rar?hash=AgADXx",
            "https://linksshortner.xyz/664592/Forza+Horizon+4+-+Atom+Guy.part06.rar?hash=AgADYB",
            "https://linksshortner.xyz/664594/Forza+Horizon+4+-+Atom+Guy.part07.rar?hash=AgADYx",
            "https://linksshortner.xyz/664596/Forza+Horizon+4+-+Atom+Guy.part08.rar?hash=AgADZh",
            "https://linksshortner.xyz/664599/Forza+Horizon+4+-+Atom+Guy.part09.rar?hash=AgADaB",
            "https://linksshortner.xyz/664603/Forza+Horizon+4+-+Atom+Guy.part10.rar?hash=AgADaR",
            "https://linksshortner.xyz/664604/Forza+Horizon+4+-+Atom+Guy.part11.rar?hash=AgADah",
            "https://linksshortner.xyz/664609/Forza+Horizon+4+-+Atom+Guy.part12.rar?hash=AgADax",
            "https://linksshortner.xyz/664610/Forza+Horizon+4+-+Atom+Guy.part13.rar?hash=AgADbB",
            "https://linksshortner.xyz/664611/Forza+Horizon+4+-+Atom+Guy.part14.rar?hash=AgADbR",
            "https://linksshortner.xyz/664613/Forza+Horizon+4+-+Atom+Guy.part15.rar?hash=AgADbh",
            "https://linksshortner.xyz/664615/Forza+Horizon+4+-+Atom+Guy.part16.rar?hash=AgADbx",
            "https://linksshortner.xyz/664617/Forza+Horizon+4+-+Atom+Guy.part17.rar?hash=AgADcx",
            "https://linksshortner.xyz/664620/Forza+Horizon+4+-+Atom+Guy.part18.rar?hash=AgADgB",
            "https://linksshortner.xyz/664621/Forza+Horizon+4+-+Atom+Guy.part19.rar?hash=AgADfR",
            "https://linksshortner.xyz/664624/Forza+Horizon+4+-+Atom+Guy.part20.rar?hash=AgADfh",
            "https://linksshortner.xyz/664625/Forza+Horizon+4+-+Atom+Guy.part21.rar?hash=AgADfx",
            "https://linksshortner.xyz/664629/Forza+Horizon+4+-+Atom+Guy.part22.rar?hash=AgADgB",
            "https://linksshortner.xyz/664633/Forza+Horizon+4+-+Atom+Guy.part23.rar?hash=AgADgR"
        ]
    },
    {
        "id": 8,
        "title": "Need for Speed: Most Wanted | NFS Most Wanted",
        "description": "Outrun the police and your rivals in this high-octane street racing game that became a classic in the NFS series.",
        "parts": 1,
        "requirements": {
            "cpu": "1.4 GHz Pentium 4 or equivalent",
            "ram": "256 MB RAM",
            "gpu": "32 MB Direct3D Video Card",
            "storage": "3 GB available space"
        },
        "images": [
            "https://mods.store.gx.me/mod/a8903921-a7f6-4b7a-ae63-771bf779e855/cover/242dd251-a963-4ea8-adb9-ae9b4ecb224c/webp-1280x720?d87fa3494354aef6d1dd9323d5207128",
            "https://i.ytimg.com/vi/KbO7Fs4vLvs/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBHSrWSj7lGNc2_weetAlrlaVjNPw",
            "https://s2.dmcdn.net/v/Sxa1H1WZmifvDGw0I/x1080"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664658/NFS+MW+2005+-+ATOM+GUY.zip?hash=AgADUx"
        ]
    },
    {
        "id": 14,
        "title": "FIFA 18",
        "description": "Experience the excitement of football with stunning graphics and gameplay enhancements in FIFA 18.",
        "parts": 8,
        "requirements": {
            "cpu": "Intel Core i3-2100 or AMD Phenom II X4 965",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 460 or AMD Radeon R7 260",
            "storage": "50 GB available space"
        },
        "images": [
            "https://www.nintendo.com/eu/media/images/10_share_images/games_15/nintendo_switch_4/H2x1_NSwitch_EASportsFifa18_image1280w.jpg",
            "https://www.jiomart.com/images/product/original/rvggle1l87/electronic-arts-sports-fifa-18-ps4-product-images-orvggle1l87-p604093135-1-202308251436.jpg?im=Resize=(1000,1000)",
            "https://www.godisageek.com/wp-content/uploads/fifa-18-career-mode-liverpool.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664761/FIFA+18+-+Atom+Guy.part01.rar?hash=AgADDR",
            "https://linksshortner.xyz/664756/FIFA+18+-+Atom+Guy.part02.rar?hash=AgADEB",
            "https://linksshortner.xyz/664748/FIFA+18+-+Atom+Guy.part03.rar?hash=AgADGB",
            "https://linksshortner.xyz/664759/FIFA+18+-+Atom+Guy.part04.rar?hash=AgADHB",
            "https://linksshortner.xyz/664750/FIFA+18+-+Atom+Guy.part05.rar?hash=AgADIB",
            "https://linksshortner.xyz/664752/FIFA+18+-+Atom+Guy.part06.rar?hash=AgADJB",
            "https://linksshortner.xyz/664754/FIFA+18+-+Atom+Guy.part07.rar?hash=AgADMB",
            "https://linksshortner.xyz/664758/FIFA+18+-+Atom+Guy.part08.rar?hash=AgADMh"
        ]
    },
    {
        "id": 15,
        "title": "Minecraft",
        "description": "Build, explore, and survive in this blocky, pixelated world filled with endless possibilities.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Core i3-3210 or AMD A8-7600",
            "ram": "4 GB RAM",
            "gpu": "Intel HD Graphics 4000 or AMD Radeon R5",
            "storage": "1 GB available space"
        },
        "images": [
            "https://assets.nuuvem.com/image/upload/v1/products/62f3c54f65d8fa7046eea12e/sharing_images/vvmelr55khbxp3myxj46.jpg",
            "https://cdn.britannica.com/62/200262-050-AFE1BDFF/Players-Minecraft-worlds-way-blocks-roaming-characters.jpg",
            "https://www.merlinentertainments.biz/media/6803/images-courtesy-of-merlin-and-tm-mojang-ab-2.jpg?anchor=center&mode=crop&width=980&height=570&rnd=133763995550000000&format=webp"
        ],
        "downloadLinks": [
            "https://eaglercraft.com/"
        ]
    },
    {
        "id": 12,
        "title": "Bully: Scholarship Edition",
        "description": "Play as Jimmy Hopkins as you navigate the social hierarchy of Bullworth Academy in this action-adventure game filled with pranks and challenges.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Pentium 4 (3+ GHZ) / AMD Athlon 3000+",
            "ram": "1 GB RAM",
            "gpu": "NVIDIA 6800 or ATI Radeon X1300",
            "storage": "4.7 GB available space"
        },
        "images": [
            "https://crotorrents.com/wp-content/uploads/2017/04/download-6.jpg",
            "https://thepcgames.net/wp-content/uploads/2018/04/Bully-Scholarship-Edition-PC-Game-Free-Download.jpg",
            "https://i.ytimg.com/vi/BVSghGUqALI/hq720.jpg?sqp=-oaymwE7CK4FEIIDSFryq4qpAy0IARUAAAAAGAElAADIQj0AgKJD8AEB-AH-CYAC0AWKAgwIABABGGUgWShNMA8=&rs=AOn4CLAh4cpWTcXBL_6sOb04Frn-5bVBRg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664662/Bully+-+Atom+Guy+Edition.rar?hash=AgADoR"
        ]
    },
    {
        "id": 13,
        "title": "Granny",
        "description": "Survive and escape a creepy house while avoiding the wrath of Granny in this thrilling horror game.",
        "parts": 1,
        "requirements": {
            "cpu": "Intel Core 2 Duo or equivalent",
            "ram": "2 GB RAM",
            "gpu": "Intel HD Graphics 4000",
            "storage": "500 MB available space"
        },
        "images": [
            "https://i.ytimg.com/vi/pURCRidtEZY/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAeprzon9DQK_SNhrzFIn1WcrFgYw",
            "https://i.ytimg.com/vi/S6l4nQrR2aE/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLB0JwshFAz-5Htq9HTD8DjMvCTBKQ",
            "https://a.silvergames.com/screenshots/granny-horror/horror-game.jpg"
        ],
        "downloadLinks": [
            "https://smgpo.sharemods.com/cgi-bin/dl.cgi/ntxubsz5vebqsg3ugrr7o5pgam6fs5arkec52xoberu7ikcoz6laxvq/Granny_1_-_Atom_Guy_Edition.zip"
        ]
    },
    {
        "id": 9,
        "title": "Euro Truck Simulator 2 | ETS 2",
        "description": "Experience the life of a truck driver as you deliver cargo across Europe in this realistic truck simulator.",
        "parts": 6,
        "requirements": {
            "cpu": "Dual core CPU 2.4 GHz",
            "ram": "4 GB RAM",
            "gpu": "GeForce GTS 450-class (Intel HD 4000)",
            "storage": "3 GB available space"
        },
        "images": [
            "https://infiniteczechgames.com/wp-content/uploads/2023/11/Euro-Truck-Simulator-2-cover.jpg",
            "https://i.ytimg.com/vi/gtxWdNcRsqY/hq720.jpg?sqp=-oaymwE7CK4FEIIDSFryq4qpAy0IARUAAAAAGAElAADIQj0AgKJD8AEB-AH-CYAC0AWKAgwIABABGEsgXShlMA8=&rs=AOn4CLBvQktvcNxaJeIcAnBfh7ybpknobQ",
            "https://i.ytimg.com/vi/zUT0JsR5KYM/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/525622/Euro+Truck+Simulator+2+-+Atom+Guy.part1.rar?hash=AgAD7h",
            "https://linksshortner.xyz/525615/Euro+Truck+Simulator+2+-+Atom+Guy.part2.rar?hash=AgAD9h",
            "https://linksshortner.xyz/525624/Euro+Truck+Simulator+2+-+Atom+Guy.part3.rar?hash=AgAD_R",
            "https://linksshortner.xyz/525611/Euro+Truck+Simulator+2+-+Atom+Guy.part4.rar?hash=AgADAh",
            "https://linksshortner.xyz/525613/Euro+Truck+Simulator+2+-+Atom+Guy.part5.rar?hash=AgADBx",
            "https://linksshortner.xyz/525617/Euro+Truck+Simulator+2+-+Atom+Guy.part6.rar?hash=AgADDR"
        ]
    },
    {
        "id": 10,
        "title": "BeamNG.drive",
        "description": "Experience realistic soft-body physics and open-world exploration with a variety of vehicles in this driving simulation.",
        "parts": 13,
        "requirements": {
            "cpu": "AMD FX-6300 or Intel i5-4430",
            "ram": "8 GB RAM",
            "gpu": "NVIDIA GTX 550 Ti or AMD HD 7750",
            "storage": "20 GB available space"
        },
        "images": [
            "https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/284160/capsule_616x353.jpg?t=1733838013",
            "https://i.ytimg.com/vi/HHLcj6T8YFk/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAvaOBBx0XHwObKgW_x8KKFEYp93g",
            "https://i.ytimg.com/vi/lUKYMavgDCY/maxresdefault.jpg"
        ],
        "downloadLinks": [
            "https://linksshortner.xyz/664708/BeamNG.drive+-+Atom+Guy.part01.rar?hash=AgADYh",
            "https://linksshortner.xyz/664699/BeamNG.drive+-+Atom+Guy.part02.rar?hash=AgADZB",
            "https://linksshortner.xyz/664691/BeamNG.drive+-+Atom+Guy.part03.rar?hash=AgADZR",
            "https://linksshortner.xyz/664703/BeamNG.drive+-+Atom+Guy.part04.rar?hash=AgADZh",
            "https://linksshortner.xyz/664693/BeamNG.drive+-+Atom+Guy.part05.rar?hash=AgADZx",
            "https://linksshortner.xyz/664695/BeamNG.drive+-+Atom+Guy.part06.rar?hash=AgADaB",
            "https://linksshortner.xyz/664697/BeamNG.drive+-+Atom+Guy.part07.rar?hash=AgADah",
            "https://linksshortner.xyz/664701/BeamNG.drive+-+Atom+Guy.part08.rar?hash=AgADax",
            "https://linksshortner.xyz/664702/BeamNG.drive+-+Atom+Guy.part09.rar?hash=AgADbB",
            "https://linksshortner.xyz/664705/BeamNG.drive+-+Atom+Guy.part10.rar?hash=AgADbR",
            "https://linksshortner.xyz/664713/BeamNG.drive+-+Atom+Guy.part11.rar?hash=AgADbh",
            "https://linksshortner.xyz/664709/BeamNG.drive+-+Atom+Guy.part12.rar?hash=AgADbx",
            "https://linksshortner.xyz/664712/BeamNG.drive+-+Atom+Guy.part13.rar?hash=AgADcB"
        ]
    }
];

// Current state
let currentSlide = 0;
let currentGame = null;

// Loading Screen
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        document.getElementById('loadingScreen').style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
        initializeGames();
    }, 2000);
});

// Initialize game cards
function initializeGames() {
    const gameGrid = document.getElementById('gameGrid');
    gameGrid.innerHTML = '';

    gameData.forEach(game => {
        const card = createGameCard(game);
        gameGrid.appendChild(card);
    });
}

// Create game card element
function createGameCard(game) {
    const card = document.createElement('div');
    card.className = 'game-card';
    card.innerHTML = `
        <img src="${game.images[0]}" alt="${game.title}" class="game-image">
        <div class="game-info">
            <h3 class="game-title">${game.title}</h3>
            <p class="game-parts">Parts: ${game.parts}</p>
            <button class="download-btn" onclick="showGameDetails(${game.id})">
                Download
            </button>
        </div>
    `;
    return card;
}

// Search functionality
const searchBar = document.getElementById('searchBar');
searchBar.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.game-card');
    
    cards.forEach(card => {
        const title = card.querySelector('.game-title').textContent.toLowerCase();
        card.style.display = title.includes(searchTerm) ? 'block' : 'none';
    });
});

// Show game details popup
function showGameDetails(gameId) {
    currentGame = gameData.find(game => game.id === gameId);
    if (!currentGame) return;

    const popup = document.getElementById('gamePopup');
    const slideshow = document.getElementById('slideshow');
    const dots = document.getElementById('slideDots');
    
    // Set game info
    document.getElementById('popupGameTitle').textContent = currentGame.title;
    document.getElementById('popupGameDescription').textContent = currentGame.description;
    
    // Set requirements
    const reqList = document.getElementById('popupRequirements');
    reqList.innerHTML = `
        <li>CPU: ${currentGame.requirements.cpu}</li>
        <li>RAM: ${currentGame.requirements.ram}</li>
        <li>GPU: ${currentGame.requirements.gpu}</li>
    `;
    document.getElementById('popupStorage').textContent = currentGame.requirements.storage;

    // Set up slideshow
    slideshow.innerHTML = '';
    dots.innerHTML = '';
    currentGame.images.forEach((img, index) => {
        // Create slide
        const slide = document.createElement('div');
        slide.className = `slide ${index === 0 ? 'active' : ''}`;
        slide.innerHTML = `<img src="${img}" alt="${currentGame.title} Screenshot ${index + 1}" class="slideshow-image">`;
        slideshow.appendChild(slide);

        // Create dot
        const dot = document.createElement('span');
        dot.className = `dot ${index === 0 ? 'active' : ''}`;
        dot.onclick = () => goToSlide(index);
        dots.appendChild(dot);
    });

    // Set up download buttons
    const downloadButtons = document.getElementById('downloadButtons');
    downloadButtons.innerHTML = '';
    currentGame.downloadLinks.forEach((link, index) => {
    const button = document.createElement('button');
    button.className = 'download-btn';
    button.textContent = `Download Part ${index + 1}`;
    button.onclick = () => initiateDownload(currentGame.title, index + 1);
    downloadButtons.appendChild(button);
    });


    // Show popup
    popup.style.display = 'flex';
    currentSlide = 0;
}

// Slideshow navigation
function changeSlide(direction) {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    
    slides[currentSlide].classList.remove('active');
    dots[currentSlide].classList.remove('active');
    
    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    
    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

function goToSlide(slideIndex) {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    
    slides[currentSlide].classList.remove('active');
    dots[currentSlide].classList.remove('active');
    
    currentSlide = slideIndex;
    
    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

// Close popup
function closePopup() {
    const popup = document.getElementById('gamePopup');
    popup.style.display = 'none';
    currentGame = null;
    currentSlide = 0;
}

// Download functionality
function initiateDownload(gameTitle, partNumber) {
    const partLink = currentGame.downloadLinks[partNumber - 1];
    if (partLink) {
        const anchor = document.createElement('a');
        anchor.href = partLink;
        anchor.target = "_blank"; // Open the link in a new tab
        anchor.download = `${gameTitle} - Part ${partNumber}`; // Optional for direct download
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
    } else {
        alert(`Download link for ${gameTitle} - Part ${partNumber} is not available.`);
    }
}


// Background animation
function createParticles() {
    const background = document.querySelector('.background-animation');
    if (!background) {
        console.error('Background animation element not found!');
        return;
    }
    for (let i = 0; i < 100; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.animationDuration = `${4 + Math.random() * 10}s`;
        particle.style.animationDelay = `${Math.random() * 5}s`;
        background.appendChild(particle);
    }
    console.log('Particles created successfully');
}

createParticles();


// Keyboard navigation for slideshow
document.addEventListener('keydown', (e) => {
    if (currentGame) {
        if (e.key === 'ArrowLeft') changeSlide(-1);
        if (e.key === 'ArrowRight') changeSlide(1);
        if (e.key === 'Escape') closePopup();
    }
});

// Close popup when clicking outside
document.getElementById('gamePopup').addEventListener('click', (e) => {
    if (e.target.id === 'gamePopup') {
        closePopup();
    }
});